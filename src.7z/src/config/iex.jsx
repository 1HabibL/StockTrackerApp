export const iex = {
    // IEX Cloud API token
    api_token: "pk_f6ca7554462e4500b594f07ce8785e92",
    // IEX Cloud API base URL
    base_url: "https://cloud.iexapis.com/stable",
  };
  